#include<stdio.h>

int main()
{
 int R=3;
 printf("Pour le cercle de rayon = %d : diametre = %d, circonference = %f et aire = %f\n", R, 2*R, 2*R*3.14, R*R*3.14); 
 return 0;
}
