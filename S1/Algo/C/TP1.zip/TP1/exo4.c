#include<stdio.h>

int main()
{
 double nb;
 printf("Saisir un nombre : ");
 scanf("%lf",&nb);
 printf("double = %lf et triple = %lf\n", 2*nb, 3*nb); 
 return 0;
}
