#include<stdio.h>

int main()
{
 printf(" taille(int) = %d\n taille(short) = %d\n taille(unsigned short) = %d\n taille(long) = %d\n taille(long long) = %d\n taille(char) = %d\n taille(float) = %d\n taille(double) = %d\n taille(long double) = %d\n",sizeof(int), sizeof(short), sizeof(unsigned short), sizeof(long), sizeof(long long), sizeof(char), sizeof(float), sizeof(double), sizeof(long double));
 return 0;
}
